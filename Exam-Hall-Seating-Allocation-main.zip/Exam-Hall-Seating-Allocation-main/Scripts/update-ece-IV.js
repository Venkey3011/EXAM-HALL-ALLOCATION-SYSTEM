// Scripts/update-I.js
document.addEventListener("DOMContentLoaded", () => {
    fetchStudents();
    fetchTotalStudents(); // Fetch and display total students count

    const studentTable = document.getElementById("student-table");

    // Event delegation for update and delete buttons
    studentTable.addEventListener("click", (event) => {
        if (event.target.classList.contains("update-btn")) {
            const id = event.target.dataset.id;
            const row = event.target.closest("tr");
            const registerNumber = row.children[1].textContent;
            const gender = row.children[3].textContent;

            editStudent(id, registerNumber, gender);
        } else if (event.target.classList.contains("delete-btn")) {
            const id = event.target.dataset.id;
            deleteStudent(id);
        }
    });
});

// Fetch students from MongoDB and display them
async function fetchStudents() {
    try {
        const response = await fetch("http://localhost:5000/api/student-ece-IV");
        const students = await response.json();

        const tableBody = document.getElementById("student-table");
        tableBody.innerHTML = ""; // Clear existing table

        students.forEach((student, index) => {
            const row = `
                <tr>
                    <td>${index + 1}</td>
                    <td>${student.registerNumber}</td>
                    <td>${student.department}</td>
                    <td>${student.gender}</td>
                    <td><button class="update-btn" data-id="${student._id}">✏️</button></td>
                    <td><button class="delete-btn" data-id="${student._id}">🗑️</button></td>
                </tr>
            `;
            tableBody.innerHTML += row;
        });
    } catch (error) {
        console.error("Error fetching students:", error);
    }
}

// Fetch and display total number of students
async function fetchTotalStudents() {
    try {
        const response = await fetch("http://localhost:5000/api/student-ece-IV/count");
        const data = await response.json();
        document.getElementById("total-students-count").textContent = data.totalStudents;
    } catch (error) {
        console.error("Error fetching total students count:", error);
    }
}

// Update Student Function
async function editStudent(id, oldRegisterNumber, oldGender) {
    document.getElementById("update-card-IV").style.display = "block";
    document.getElementById("register-number-IV").value = oldRegisterNumber;
    document.getElementById("gender-IV").value = oldGender;

    document.getElementById("save-btn-IV").onclick = async () => {
        const registerNumber = document.getElementById("register-number-IV").value.trim();
        const gender = document.getElementById("gender-IV").value;

        if (!registerNumber) {
            alert("Register Number cannot be empty!");
            return;
        }

        await fetch(`http://localhost:5000/api/student-ece-IV/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ registerNumber, department: "ECE", gender }),
        });

        document.getElementById("update-card-IV").style.display = "none";
        fetchStudents();
        fetchTotalStudents(); // Refresh total students count
    };

    document.getElementById("cancel-btn-IV").onclick = () => {
        document.getElementById("update-card-IV").style.display = "none";
    };
}

// Delete Student Function
async function deleteStudent(id) {
    document.getElementById("delete-card-IV").style.display = "block";

    document.getElementById("yes-btn-IV").onclick = async () => {
        await fetch(`http://localhost:5000/api/student-ece-IV/${id}`, { method: "DELETE" });
        document.getElementById("delete-card-IV").style.display = "none";
        fetchStudents();
        fetchTotalStudents(); // Refresh total students count
    };

    document.getElementById("no-btn-IV").onclick = () => {
        document.getElementById("delete-card-IV").style.display = "none";
    };
}