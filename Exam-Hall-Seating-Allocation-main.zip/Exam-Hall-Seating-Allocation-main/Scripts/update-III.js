document.addEventListener("DOMContentLoaded", () => {
    const updateCard = document.getElementById("update-card-III");
    const deleteCard = document.getElementById("delete-card-III");
    const registerInput = document.getElementById("register-number-III");
    const genderInput = document.getElementById("gender-III");
    const saveButton = document.getElementById("save-btn-III");
    const cancelButton = document.getElementById("cancel-btn-III");
    const errorMessage = document.getElementById("error-message-III");
    const yesButton = document.getElementById("yes-btn-III");
    const noButton = document.getElementById("no-btn-III");
    const totalStudentsElement = document.querySelector(".total-students p"); // Total students display

    let currentRow = null; // To store the row being updated or deleted

    // Function to update the total students count
    function updateTotalStudentsCount() {
        const totalRows = document.querySelectorAll("table tbody .tr-III").length;
        totalStudentsElement.textContent = `Total Students: ${totalRows}`;
    }

    // Function to add event listeners for update and delete icons
    function addRowEventListeners(row) {
        // Update icon event listener
        const pen = row.querySelector(".update .pen");
        pen.addEventListener("click", (event) => {
            currentRow = event.target.closest("tr");

            // Prefill the card inputs with existing data
            const registerNumber = currentRow.querySelector(".register-number").textContent;
            const gender = currentRow.querySelector(".gender").textContent;

            registerInput.value = registerNumber;
            genderInput.value = gender;

            // Clear error message
            errorMessage.textContent = "";

            // Show the update card
            updateCard.style.display = "block";
        });

        // Delete icon event listener
        const trash = row.querySelector(".delete .trash");
        trash.addEventListener("click", (event) => {
            currentRow = event.target.closest("tr");

            // Show the delete confirmation card
            deleteCard.style.display = "block";
        });
    }

    // Event listener for the save button in the update card
    saveButton.addEventListener("click", () => {
        const registerValue = registerInput.value.trim();

        // Validate the register number (must be exactly 12 digits)
        if (!/^\d{12}$/.test(registerValue)) {
            errorMessage.textContent = "Register number must be in 12 digits";
            return; // Do not proceed further
        }

        if (currentRow) {
            // Update the table row with the new values
            currentRow.querySelector(".register-number").textContent = registerValue;
            currentRow.querySelector(".gender").textContent = genderInput.value;

            // Hide the update card
            updateCard.style.display = "none";
        }
    });

    // Event listener for the cancel button in the update card
    cancelButton.addEventListener("click", () => {
        // Hide the card and clear the error message
        updateCard.style.display = "none";
        errorMessage.textContent = "";
    });

    // Event listener for the YES button in the delete card
    yesButton.addEventListener("click", () => {
        if (currentRow) {
            currentRow.remove(); // Remove the current row from the table

            // Reassign SI.No values to ensure they are in sequence
            updateSerialNumbers();

            // Update total students count
            updateTotalStudentsCount();

            // Hide the delete card
            deleteCard.style.display = "none";
            currentRow = null; // Clear the currentRow reference
        }
    });

    // Event listener for the NO button in the delete card
    noButton.addEventListener("click", () => {
        // Simply hide the delete card
        deleteCard.style.display = "none";
        currentRow = null; // Clear the currentRow reference
    });

    // Function to update SI.No column values in sequence
    function updateSerialNumbers() {
        const rows = document.querySelectorAll("table tbody .tr-III");
        rows.forEach((row, index) => {
            row.querySelector(".serial-number").textContent = index + 1; // Update SI.No
        });
    }

    // Add event listener for dynamically adding a new student
    document.querySelector(".add-student button").addEventListener("click", () => {
        const tableBody = document.querySelector("table tbody");
        const section = document.querySelector("section");
        const newRow = document.createElement("tr");
        newRow.classList.add("tr-III");
    
        newRow.innerHTML = `
            <td class="serial-number">${tableBody.children.length + 1}</td>
            <td class="register-number">New Register</td>
            <td>${section.className.split('-')[0]}</td>       
            <td class="gender">New Gender</td>
            <td class="update"><span class="pen">✏️</span></td>
            <td class="delete"><span class="trash">🗑️</span></td>
        `;
    
        tableBody.appendChild(newRow);
    
        // Add event listeners for the new row
        addRowEventListeners(newRow);
    
        // Update total students count
        updateTotalStudentsCount();
    }, { once: false }); // Make sure the listener doesn't trigger multiple times.
    

    // Add event listeners for existing rows
    document.querySelectorAll("table tbody .tr-III").forEach((row) => {
        addRowEventListeners(row);
    });

    // Initial update of total students count
    updateTotalStudentsCount();
}); 

