// Scripts/login.js
const container = document.getElementById("container");
const registerbtn = document.getElementById("register");
const loginbtn = document.getElementById("login");

registerbtn.addEventListener("click", () => {
  container.classList.add("active");
});

loginbtn.addEventListener("click", () => {
  container.classList.remove("active");
});

async function signup() {
  const name = document.querySelector(".sign-up input[placeholder='Name']").value;
  const email = document.querySelector(".sign-up input[placeholder='Email']").value;
  const password = document.querySelector(".sign-up input[placeholder='Password']").value;

  const response = await fetch("http://localhost:5000/api/users/signup", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name, email, password }),
  });

  const data = await response.json();
  alert(data.message);
}

async function signin() {
  const email = document.querySelector(".sign-in input[placeholder='Email']").value;
  const password = document.querySelector(".sign-in input[placeholder='Password']").value;

  const response = await fetch("http://localhost:5000/api/users/signin", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password }),
  });

  const data = await response.json();
  if (response.ok) {
    alert(data.message);
    // Redirect to dashboard
    window.location.href = "dashboard.html";
  } else {
    alert(data.message);
  }
}