document.addEventListener("DOMContentLoaded", () => {
    const stepHeaders = document.querySelectorAll(".step-header");
    const lectureHeaders = document.querySelectorAll(".lecture-header");

    // Toggle Steps
    stepHeaders.forEach(header => {
        header.addEventListener("click", () => {
            header.classList.toggle("active");
            const content = header.nextElementSibling;
            content.style.maxHeight
                ? (content.style.maxHeight = null)
                : (content.style.maxHeight = content.scrollHeight + "px");
        });
    });

    // Toggle Lectures
    lectureHeaders.forEach(header => {
        header.addEventListener("click", () => {
            header.classList.toggle("active");
            const content = header.nextElementSibling;
            content.style.maxHeight
                ? (content.style.maxHeight = null)
                : (content.style.maxHeight = content.scrollHeight + "px");
        });
    });
});
