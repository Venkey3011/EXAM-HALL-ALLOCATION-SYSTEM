// Scripts/addStudent.js
document.addEventListener("DOMContentLoaded", () => {
    const addStudentBtn = document.getElementById("add-student-btn");
    const addStudentCard = document.getElementById("add-student-card");
    const cancelAddBtn = document.getElementById("cancel-add-btn");
    const saveAddBtn = document.getElementById("save-add-btn");

    const registerNumberInput = document.getElementById("register-number");
    const genderInput = document.getElementById("gender");

    // Show the Add Student Card
    addStudentBtn.addEventListener("click", () => {
        addStudentCard.style.display = "block";
    });

    // Hide the card on cancel
    cancelAddBtn.addEventListener("click", () => {
        addStudentCard.style.display = "none";
        clearInputs();
    });

    // Save student without prompt
    saveAddBtn.addEventListener("click", async () => {
        const registerNumber = registerNumberInput.value.trim();
        const gender = genderInput.value;

        if (!registerNumber) {
            alert("Register Number is required!");
            return;
        }

        try {
            const response = await fetch("http://localhost:5000/api/student-aids-II", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ serialNo: Date.now(), registerNumber, department: "AIDS", gender }),
            });

            if (!response.ok) {
                throw new Error("Failed to add student");
            }

            addStudentCard.style.display = "none";
            clearInputs();
            fetchStudents(); // Refresh students list
            fetchTotalStudents(); // Refresh total students count
        } catch (error) {
            console.error("Error adding student:", error);
            alert("Failed to add student. Please try again.");
        }
    });

    // Clear input fields
    function clearInputs() {
        registerNumberInput.value = "";
        genderInput.value = "Male";
    }

    // Fetch students and update the table
    async function fetchStudents() {
        try {
            const response = await fetch("http://localhost:5000/api/student-aids-II");
            const students = await response.json();

            const tableBody = document.getElementById("student-table");
            tableBody.innerHTML = ""; // Clear existing table

            students.forEach((student, index) => {
                const row = `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${student.registerNumber}</td>
                        <td>${student.department}</td>
                        <td>${student.gender}</td>
                        <td><button class="update-btn" data-id="${student._id}">✏️</button></td>
                        <td><button class="delete-btn" data-id="${student._id}">🗑️</button></td>
                    </tr>
                `;
                tableBody.innerHTML += row;
            });
        } catch (error) {
            console.error("Error fetching students:", error);
        }
    }

    // Fetch and display total number of students
    async function fetchTotalStudents() {
        try {
            const response = await fetch("http://localhost:5000/api/student-aids-II/count");
            const data = await response.json();
            document.getElementById("total-students-count").textContent = data.totalStudents;
        } catch (error) {
            console.error("Error fetching total students count:", error);
        }
    }
});