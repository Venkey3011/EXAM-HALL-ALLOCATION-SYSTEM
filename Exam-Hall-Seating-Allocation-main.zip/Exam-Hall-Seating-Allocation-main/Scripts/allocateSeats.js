document.addEventListener("DOMContentLoaded", () => {
    document.querySelector(".Allocate-btn").addEventListener("click", async (event) => {
        event.preventDefault(); // Prevent form submission
        
        // Get selected departments
        let selectedDepartments = [];
        document.querySelectorAll(".department-card input[type='checkbox']:checked").forEach((checkbox) => {
            selectedDepartments.push(checkbox.parentElement.textContent.trim());
        });

        // Get selected date
        let examDate = document.getElementById("date").value;

        // Get selected session (FN / AN)
        let session = document.querySelector("input[name='option']:checked");
        let examSession = session ? (session.value === "option1" ? "FN" : "AN") : null;

        // Validation
        if (selectedDepartments.length === 0 || !examDate || !examSession) {
            alert("Please select all required fields!");
            return;
        }

        // Create request payload
        const requestData = {
            departments: selectedDepartments,
            date: examDate,
            session: examSession
        };

        try {
            // Send data to the backend
            let response = await fetch("/allocate-seats", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(requestData)
            });

            let result = await response.json();

            if (response.ok) {
                alert("Seat allocation successful!");
                window.location.href = "Report.html"; // Redirect to the report page
            } else {
                alert(`Error: ${result.message}`);
            }
        } catch (error) {
            console.error("Allocation failed:", error);
            alert("Failed to allocate seats. Try again.");
        }
    });
});
