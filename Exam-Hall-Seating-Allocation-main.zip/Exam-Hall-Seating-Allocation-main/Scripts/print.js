function printReport() {
    // Hide unnecessary buttons before printing
    document.querySelector(".print-btn").style.display = "none";
    document.querySelector(".exit-btn").style.display = "none";

    // Set timeout to ensure the print settings apply
    setTimeout(() => {
        window.print(); // Open print dialog
    }, 500);

    // Restore buttons after print
    setTimeout(() => {
        document.querySelector(".print-btn").style.display = "inline-block";
        document.querySelector(".exit-btn").style.display = "inline-block";
    }, 1000);
}
