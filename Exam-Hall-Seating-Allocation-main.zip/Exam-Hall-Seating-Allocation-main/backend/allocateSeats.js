const mongoose = require("mongoose");
const Hall = require("./models/Hall");
const Student = require("./models/Student");
const Allocation = require("./models/Allocation");

mongoose.connect("mongodb://localhost:27017/Exam-Hall-Web", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log("MongoDB connected for allocation"))
  .catch(err => console.log(err));

async function allocateSeats() {
  try {
    // Fetch all students
    const maleStudents = await Student.find({ gender: "Male" });
    const femaleStudents = await Student.find({ gender: "Female" });

    // Shuffle students randomly for fairness
    function shuffle(array) {
      return array.sort(() => Math.random() - 0.5);
    }

    const shuffledMales = shuffle(maleStudents);
    const shuffledFemales = shuffle(femaleStudents);

    // Fetch all halls
    const mainBlockHalls = await Hall.find({ block: "Main Block" });
    const eceBlockHalls = await Hall.find({ block: "ECE Block" });

    // Seat allocation function
    function allocateToHalls(students, halls) {
      let allocation = [];
      let studentIndex = 0;

      halls.forEach((hall) => {
        let tables = [];
        for (let i = 0; i < hall.capacity; i += 2) {
          if (studentIndex + 1 < students.length) {
            // Ensure students are from different departments
            let student1 = students[studentIndex];
            let student2 = students[studentIndex + 1];

            if (student1.department !== student2.department) {
              tables.push({ tableNumber: i / 2 + 1, students: [student1, student2] });
              studentIndex += 2;
            }
          }
        }
        allocation.push({ hallName: hall.hallName, tables });
      });

      return allocation;
    }

    // Allocate males to Main Block
    const maleAllocation = allocateToHalls(shuffledMales, mainBlockHalls);
    // Allocate females to ECE Block
    const femaleAllocation = allocateToHalls(shuffledFemales, eceBlockHalls);

    // Save allocations to MongoDB
    await Allocation.insertMany([...maleAllocation, ...femaleAllocation]);

    console.log("Seating allocation completed successfully!");
    mongoose.connection.close();
  } catch (err) {
    console.error("Error in seating allocation:", err);
  }
}

allocateSeats();
