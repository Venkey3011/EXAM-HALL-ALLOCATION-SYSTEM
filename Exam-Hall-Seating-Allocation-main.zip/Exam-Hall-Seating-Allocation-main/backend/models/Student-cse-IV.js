// models/Student-cse-II.js
const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  serialNo: Number,
  registerNumber: String,
  department: String,
  gender: String,
}, { collection: "student-cse-IV"}); // Explicitly set the collection name

module.exports = mongoose.model("Student-cse-IV", studentSchema);