const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
    registerNumber: String,
    departmentYear: String,  // Example: "cse-I", "cse-II", etc.
    gender: String
});

module.exports = mongoose.model("Student", studentSchema);
