const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  serialNo: Number,
  registerNumber: String,
  department: String,
  gender: String,
}, { collection: "student-ece-IV"}); 

module.exports = mongoose.model("Student-ece-IV", studentSchema);