const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  serialNo: Number,
  registerNumber: String,
  department: String,
  gender: String,
}, { collection: "student-eee-II"}); // Explicitly set the collection name

module.exports = mongoose.model("Student-eee-II", studentSchema);