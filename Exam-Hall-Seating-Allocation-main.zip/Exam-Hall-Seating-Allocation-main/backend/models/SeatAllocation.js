// Scripts/seatAllocation.js

// Paste the fetchStudents function here
async function fetchStudents(department, year) {
    const response = await fetch(`/api/students?department=${department}&year=${year}`);
    const data = await response.json();
    return data;
}

// Example usage of fetchStudents
async function allocateSeats() {
    const selectedDepartments = Array.from(document.querySelectorAll('input[name="departmentYear"]:checked'))
                                    .map(input => input.value);
    const examDate = document.getElementById("date").value;
    const session = document.querySelector('input[name="session"]:checked')?.value;

    if (selectedDepartments.length === 0 || !examDate || !session) {
        alert("Please select departments, a date, and a session.");
        return;
    }

    // Fetch student data for each selected department and year
    const studentData = [];
    for (const deptYear of selectedDepartments) {
        const [department, year] = deptYear.split("-");
        const students = await fetchStudents(department, year); // Use fetchStudents here
        studentData.push({ department, year, students });
    }

    // Store the data in localStorage before redirecting
    localStorage.setItem("seatAllocationData", JSON.stringify({
        departments: selectedDepartments,
        examDate,
        session,
        studentData
    }));

    // Redirect to the output page
    window.location.href = "../Output.html";
}