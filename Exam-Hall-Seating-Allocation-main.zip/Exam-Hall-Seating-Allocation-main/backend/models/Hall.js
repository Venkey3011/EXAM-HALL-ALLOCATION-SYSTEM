const mongoose = require("mongoose");

const hallSchema = new mongoose.Schema({
    name: String,
    block: String,  // "Main Block" for males, "ECE Block" for females
    capacity: Number
});

module.exports = mongoose.model("Hall", hallSchema);
