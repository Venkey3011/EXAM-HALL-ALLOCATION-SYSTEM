// models/Student-cse-I.js
const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  serialNo: Number,
  registerNumber: String,
  department: String,
  gender: String,
}, { collection: "student-cse-I"}); // Explicitly set the collection name

module.exports = mongoose.model("Student-cse-I", studentSchema);