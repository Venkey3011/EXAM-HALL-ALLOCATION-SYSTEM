// server.js
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const connectDB = require("./config/db");
const userRoutes = require("./routes/userRoutes");
const seatAllocationRoutes = require("./routes/seatAllocationRoutes");
const hallRoutes = require("./routes/hallRoutes");
const Hall = require("./models/Hall");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Database Connection
connectDB();

// User Routes
app.use("/api/users", userRoutes);
app.use("/allocate-seats", seatAllocationRoutes);
app.use("/api/halls", hallRoutes);


// Dynamically Load Student Routes
const routesDir = path.join(__dirname, "routes");
fs.readdirSync(routesDir).forEach((file) => {
  if (file.startsWith("studentRoutes")) {
    const routeName = file.replace("studentRoutes-", "").replace(".js", "");
    const routePath = `/api/student-${routeName}`;
    const routeModule = require(`./routes/${file}`);
    app.use(routePath, routeModule);
  }
});



app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});