const mongoose = require("mongoose");
const Hall = require("./models/Hall");

// Connect to MongoDB (Change the database name to 'Exam-Hall-Web')
mongoose.connect("mongodb://localhost:27017/Exam-Hall-Web", {
  useNewUrlParser: true, 
  useUnifiedTopology: true, 
})
  .then(() => console.log("MongoDB connected to Exam-Hall-Web"))
  .catch(err => console.log(err));

// Hall data from HTML
const hallData = [
  { hallName: "MB 001", capacity: 25, block: "Main Block" },
  { hallName: "MB 002", capacity: 25, block: "Main Block" },
  { hallName: "MB 003", capacity: 25, block: "Main Block" },
  { hallName: "MB 101", capacity: 25, block: "Main Block" },
  { hallName: "MB 102", capacity: 25, block: "Main Block" },
  { hallName: "MB 103", capacity: 25, block: "Main Block" },
  { hallName: "MB 104", capacity: 25, block: "Main Block" },
  { hallName: "MB 201", capacity: 25, block: "Main Block" },
  { hallName: "MB 202", capacity: 25, block: "Main Block" },
  { hallName: "MB 203", capacity: 25, block: "Main Block" },
  { hallName: "MB 301", capacity: 25, block: "Main Block" },
  { hallName: "MB 302", capacity: 25, block: "Main Block" },
  { hallName: "MB 303", capacity: 25, block: "Main Block" },
  { hallName: "MB 304a", capacity: 25, block: "Main Block" },
  { hallName: "MB 304b", capacity: 25, block: "Main Block" },
  { hallName: "ECE 101", capacity: 25, block: "ECE Block" },
  { hallName: "ECE 102", capacity: 25, block: "ECE Block" },
  { hallName: "ECE 103", capacity: 25, block: "ECE Block" },
  { hallName: "ECE 301", capacity: 25, block: "ECE Block" },
  { hallName: "ECE 302", capacity: 25, block: "ECE Block" },
  { hallName: "ECE 303", capacity: 25, block: "ECE Block" },
];

// Insert data
Hall.insertMany(hallData)
  .then(() => {
    console.log("Hall data inserted successfully into Exam-Hall-Web!");
    mongoose.connection.close();
  })
  .catch(err => console.log(err));
