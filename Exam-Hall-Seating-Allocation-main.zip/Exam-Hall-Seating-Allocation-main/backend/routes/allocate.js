const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

// Import MongoDB models
const Hall = mongoose.model("Hall");
const Student = mongoose.model("Student");

// Seat Allocation Logic
router.post("/allocate-seats", async (req, res) => {
    try {
        const { departments, date, session } = req.body;

        // Fetch students based on selected departments
        let students = [];
        for (let dept of departments) {
            let deptStudents = await Student.find({ department: dept });
            students = students.concat(deptStudents);
        }

        // Separate male and female students
        let maleStudents = students.filter(student => student.gender === "Male");
        let femaleStudents = students.filter(student => student.gender === "Female");

        // Shuffle students randomly for fairness
        maleStudents = maleStudents.sort(() => Math.random() - 0.5);
        femaleStudents = femaleStudents.sort(() => Math.random() - 0.5);

        // Fetch available halls
        let halls = await Hall.find();
        let mainBlockHalls = halls.filter(hall => hall.block === "Main Block");
        let eceBlockHalls = halls.filter(hall => hall.block === "ECE Block");

        // Allocate Male students to Main Block
        let maleAllocation = allocateToHalls(mainBlockHalls, maleStudents);

        // Allocate Female students to ECE Block
        let femaleAllocation = allocateToHalls(eceBlockHalls, femaleStudents);

        // Save allocation results
        await saveAllocations(maleAllocation, femaleAllocation, date, session);

        res.json({ message: "Seats allocated successfully!" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Server Error" });
    }
});

// Function to allocate students to halls
function allocateToHalls(halls, students) {
    let allocation = [];
    let studentIndex = 0;

    for (let hall of halls) {
        let hallAllocation = { hall: hall.name, tables: [] };
        for (let i = 0; i < 25; i++) {  // 25 tables per hall
            if (studentIndex >= students.length) break;
            let table = { student1: students[studentIndex++] };
            if (studentIndex < students.length) {
                table.student2 = students[studentIndex++];
            }
            hallAllocation.tables.push(table);
        }
        allocation.push(hallAllocation);
        if (studentIndex >= students.length) break;
    }
    return allocation;
}

// Function to store allocation results
async function saveAllocations(maleAllocations, femaleAllocations, date, session) {
    let allocationResults = [...maleAllocations, ...femaleAllocations];
    for (let alloc of allocationResults) {
        await Hall.updateOne(
            { name: alloc.hall },
            { $set: { allocation: alloc.tables, date: date, session: session } }
        );
    }
}

module.exports = router;
