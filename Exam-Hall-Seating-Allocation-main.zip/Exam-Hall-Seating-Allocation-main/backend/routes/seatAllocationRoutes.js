const express = require("express");
const router = express.Router();
const SeatAllocation = require("../models/SeatAllocation");
const Student = require("../models/Student");
const Hall = require("../models/Hall");

router.post("/", async (req, res) => {
    try {
        const { departments, examDate, session } = req.body;
        if (!departments || !examDate || !session) {
            return res.status(400).json({ message: "Missing required fields" });
        }

        // Fetch students only from the selected departments
        const students = await Student.find({ departmentYear: { $in: departments } });

        // Separate students by gender
        const maleStudents = students.filter(s => s.gender === "Male");
        const femaleStudents = students.filter(s => s.gender === "Female");

        // Fetch available halls
        const mainBlockHalls = await Hall.find({ block: "Main Block" });
        const eceBlockHalls = await Hall.find({ block: "ECE Block" });

        // Function to allocate seats
        function allocateSeats(students, halls) {
            let seatAllocation = [];
            let studentIndex = 0;

            for (let hall of halls) {
                let hallSeats = [];
                for (let i = 0; i < 25; i++) {
                    if (studentIndex >= students.length) break;
                    let student1 = students[studentIndex++];
                    let student2 = null;

                    while (studentIndex < students.length) {
                        if (students[studentIndex].department !== student1.department) {
                            student2 = students[studentIndex++];
                            break;
                        } else {
                            studentIndex++;
                        }
                    }

                    hallSeats.push({ table: i + 1, student1, student2 });
                }
                seatAllocation.push({ hall: hall.name, seats: hallSeats });
            }

            return seatAllocation;
        }

        // Allocate seats
        let maleAllocation = allocateSeats(maleStudents, mainBlockHalls);
        let femaleAllocation = allocateSeats(femaleStudents, eceBlockHalls);

        // Store in MongoDB
        await SeatAllocation.create({
            examDate,
            session,
            allocations: [...maleAllocation, ...femaleAllocation]
        });

        res.json({ message: "Seating allocation completed successfully!" });
    } catch (error) {
        console.error("Error allocating seats:", error);
        res.status(500).json({ message: "Internal server error" });
    }
});

module.exports = router;
