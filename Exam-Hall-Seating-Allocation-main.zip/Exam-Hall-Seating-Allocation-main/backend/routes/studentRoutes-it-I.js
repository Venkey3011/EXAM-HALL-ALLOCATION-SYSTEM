// routes/studentRoutes.js
const express = require("express");
const router = express.Router();
const Student = require("../models/Student-it-I");

// Get all students
router.get("/", async (req, res) => {
  try {
    const students = await Student.find();
    res.json(students);
  } catch (error) {
    res.status(500).json({ message: "Error fetching students" });
  }
});

// Add a new student
router.post("/", async (req, res) => {
  const { serialNo, registerNumber, department, gender } = req.body;

  try {
    const newStudent = new Student({ serialNo, registerNumber, department, gender });
    await newStudent.save();
    res.status(201).json({ message: "Student added successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error adding student" });
  }
});

// Update a student
router.put("/:id", async (req, res) => {
  const { serialNo, registerNumber, department, gender } = req.body;

  try {
    await Student.findByIdAndUpdate(req.params.id, { serialNo, registerNumber, department, gender });
    res.json({ message: "Student updated successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error updating student" });
  }
});

// Delete a student
router.delete("/:id", async (req, res) => {
  try {
    await Student.findByIdAndDelete(req.params.id);
    res.json({ message: "Student deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting student" });
  }
});

// Get total number of students
router.get("/count", async (req, res) => {
  try {
    const count = await Student.countDocuments();
    res.json({ totalStudents: count });
  } catch (error) {
    res.status(500).json({ message: "Error fetching student count" });
  }
});

module.exports = router;