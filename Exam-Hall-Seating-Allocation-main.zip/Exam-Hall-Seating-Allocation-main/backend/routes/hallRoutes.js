const express = require("express");
const router = express.Router();
const Hall = require("../models/Hall");

// Get all halls
router.get("/", async (req, res) => {
  try {
    const halls = await Hall.find();
    res.json(halls);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
